﻿/**
 * NebulaSDK.h - Nebula 网络验证纯 DLL SDK 公共头文件
 *
 * 协议版本: Nebula 3.1 (PROTO = 31)
 * 调用约定: __stdcall
 * 字符串:   UTF-8 char*
 *
 * 目标调用方: 易语言、C/C++、C#、Delphi 等支持调用 Windows DLL 的语言
 *
 * 使用流程:
 *   Nebula_Create -> SetServer/SetAppKey/... -> Handshake -> Init -> Login -> 业务API -> Logout -> Destroy
 */

#pragma once

#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

/* ================================================================== */
/*  句柄定义                                                           */
/* ================================================================== */

/** SDK 实例句柄（易语言侧当作整数型使用） */
typedef void* NEBULA_HANDLE;

/* ================================================================== */
/*  DLL 错误码                                                         */
/* ================================================================== */

#define NEBULA_OK                 0
#define NEBULA_ERR_INVALID_HANDLE  (-1)
#define NEBULA_ERR_INVALID_ARG     (-2)
#define NEBULA_ERR_NOT_INIT        (-3)
#define NEBULA_ERR_NETWORK         (-4)
#define NEBULA_ERR_TIMEOUT         (-5)
#define NEBULA_ERR_HTTP            (-6)
#define NEBULA_ERR_JSON            (-7)
#define NEBULA_ERR_CRYPTO          (-8)
#define NEBULA_ERR_BUFFER_SMALL    (-9)
#define NEBULA_ERR_INTERNAL        (-10)
#define NEBULA_ERR_NOT_LOGGED_IN   (-11)
#define NEBULA_ERR_SESSION_EXPIRED (-12)

/* ================================================================== */
/*  SDK 状态                                                           */
/* ================================================================== */

enum NebulaState {
    NEBULA_STATE_CREATED       = 0,
    NEBULA_STATE_HANDSHAKING   = 1,
    NEBULA_STATE_ESTABLISHED   = 2,
    NEBULA_STATE_INITIALIZED   = 3,
    NEBULA_STATE_LOGGED_IN     = 4,
    NEBULA_STATE_LOGGED_OUT    = 5,
    NEBULA_STATE_DESTROYED     = 6,
};

/* ================================================================== */
/*  导出宏                                                             */
/* ================================================================== */

#ifdef NEBULADLL_EXPORTS
#define NEBULA_API __declspec(dllexport)
#else
#define NEBULA_API __declspec(dllimport)
#endif

/* ================================================================== */
/*  生命周期                                                           */
/* ================================================================== */

/** 创建 SDK 实例，返回非 NULL 表示成功 */
NEBULA_API NEBULA_HANDLE __stdcall Nebula_Create(void);

/** 销毁 SDK 实例，释放所有内部资源 */
NEBULA_API void __stdcall Nebula_Destroy(NEBULA_HANDLE handle);

/* ================================================================== */
/*  配置 API                                                           */
/* ================================================================== */

/** 设置服务器地址，如 "https://example.com" */
NEBULA_API int __stdcall Nebula_SetServer(NEBULA_HANDLE handle, const char* server_url);

/** 设置 AppKey */
NEBULA_API int __stdcall Nebula_SetAppKey(NEBULA_HANDLE handle, const char* app_key);

/** 设置客户端版本，如 "2.65.39" */
NEBULA_API int __stdcall Nebula_SetClientVersion(NEBULA_HANDLE handle, const char* version);

/** 设置机器 ID */
NEBULA_API int __stdcall Nebula_SetMachineId(NEBULA_HANDLE handle, const char* machine_id);

/** 设置设备信息（可选） */
NEBULA_API int __stdcall Nebula_SetDeviceInfo(NEBULA_HANDLE handle,
    const char* board, const char* cpu, const char* disk,
    const char* bios, const char* mac, const char* gpu);

/** 设置响应签名公钥 (PEM 格式 ES256 公钥，用于验证握手/响应签名) */
NEBULA_API int __stdcall Nebula_SetRespSignKey(NEBULA_HANDLE handle, const char* pem_public_key);

/* ================================================================== */
/*  握手与初始化                                                       */
/* ================================================================== */

/** Nebula 3.1 ECDH 握手 */
NEBULA_API int __stdcall Nebula_Handshake(NEBULA_HANDLE handle);

/** 初始化（拉取服务端配置） */
NEBULA_API int __stdcall Nebula_Init(NEBULA_HANDLE handle);

/* ================================================================== */
/*  登录 API                                                           */
/* ================================================================== */

/** 用户名 + 密码登录 */
NEBULA_API int __stdcall Nebula_LoginPassword(NEBULA_HANDLE handle,
    const char* username, const char* password);

/** 用户名 + 激活码登录 */
NEBULA_API int __stdcall Nebula_LoginUsernameCode(NEBULA_HANDLE handle,
    const char* username, const char* code);

/** 激活码直登 (服务端 method=code，仅需 code) */
NEBULA_API int __stdcall Nebula_LoginCard(NEBULA_HANDLE handle, const char* code);

/* ================================================================== */
/*  业务 API                                                           */
/* ================================================================== */

/** 心跳 */
NEBULA_API int __stdcall Nebula_Heartbeat(NEBULA_HANDLE handle);

/** 获取用户信息 */
NEBULA_API int __stdcall Nebula_GetUserInfo(NEBULA_HANDLE handle);

/** 获取设备列表 */
NEBULA_API int __stdcall Nebula_GetDevices(NEBULA_HANDLE handle);

/** 激活卡密 */
NEBULA_API int __stdcall Nebula_Activate(NEBULA_HANDLE handle, const char* code);

/** 解绑设备 (all=1 解绑全部，需密码) */
NEBULA_API int __stdcall Nebula_Unbind(NEBULA_HANDLE handle, const char* password, int all);

/** 获取公告 (notice_id 可为 NULL) */
NEBULA_API int __stdcall Nebula_GetNotice(NEBULA_HANDLE handle, const char* notice_id);

/** 版本检查 (channel 可为 NULL，默认 "stable") */
NEBULA_API int __stdcall Nebula_CheckVersion(NEBULA_HANDLE handle, const char* channel);

/** 获取在线人数 */
NEBULA_API int __stdcall Nebula_GetOnline(NEBULA_HANDLE handle);

/** 退出登录 */
NEBULA_API int __stdcall Nebula_Logout(NEBULA_HANDLE handle);

/* ================================================================== */
/*  结果与状态                                                        */
/* ================================================================== */

/** 获取上次操作的 JSON 结果（UTF-8），调用方提供缓冲区 */
NEBULA_API int __stdcall Nebula_GetResult(NEBULA_HANDLE handle, char* buffer, uint32_t buffer_size);

/** 获取最后错误码 */
NEBULA_API int __stdcall Nebula_GetLastError(NEBULA_HANDLE handle);

/** 获取最后错误描述（UTF-8），调用方提供缓冲区 */
NEBULA_API int __stdcall Nebula_GetLastErrorMessage(NEBULA_HANDLE handle, char* buffer, uint32_t buffer_size);

/* ================================================================== */
/*  Feature 解密                                                      */
/* ================================================================== */

/** 解密 Feature 数据 (NF1 格式) */
NEBULA_API int __stdcall Nebula_DecryptFeature(NEBULA_HANDLE handle,
    const char* feature_data, char* buffer, uint32_t buffer_size);

/* ================================================================== */
/*  Runtime 安全策略（服务端下发）与事件上报                            */
/* ================================================================== */

/**
 * 获取最近一次 init / login / heartbeat 下发的 runtime_policy 原文 JSON。
 * 未收到过策略时返回空 JSON "{}"。
 */
NEBULA_API int __stdcall Nebula_GetRuntimePolicy(NEBULA_HANDLE handle,
    char* buffer, uint32_t buffer_size);

/**
 * 有限自检 + 按策略处置 + 事件上报。
 *
 * 运行「可靠不误报」检测集（用户态调试器 / 远程调试 / PEB NtGlobalFlag），
 * 命中后按服务端 runtime_policy 的处置动作执行：
 *   REPORT         仅上报事件（不干预运行）
 *   POPUP          上报事件 + 弹出提示框
 *   TERMINATE      上报事件 + 置错误态（lastError = -20）
 *   REVOKE_SESSION 上报 CRITICAL 事件（服务端会同步封禁会话）
 * 未命中时无副作用。建议在心跳循环中周期调用。
 *
 * 返回: 0=未命中；1=REPORT；2=POPUP；3=TERMINATE；4=REVOKE_SESSION；负数=DLL 错误
 */
NEBULA_API int __stdcall Nebula_SecurityCheck(NEBULA_HANDLE handle);

/**
 * 上报一条运行时安全事件到服务端（runtime_security_event 接口）。
 *
 * 参数:
 *   event_type  - 事件类型（如 DEBUGGER_VM_CHECK / RUNTIME_CHECK，服务端大写归一）
 *   risk_level  - LOW / MEDIUM / HIGH / CRITICAL（可传 NULL，默认 HIGH）
 *   risk_score  - 风险分 0-100000（可传 0，服务端按事件类型修正）
 *   detail_json - 附加明细 JSON 对象（如 {"module_name":"x.dll"}，可传 NULL）
 *
 * 网络失败时事件入队，随下一次心跳自动补发。
 * 返回: 0=服务端已接受；其他负数=DLL 层错误（事件仍会入队补发）
 */
NEBULA_API int __stdcall Nebula_ReportRuntimeEvent(NEBULA_HANDLE handle,
    const char* event_type, const char* risk_level, int risk_score,
    const char* detail_json);

/* ================================================================== */
/*  自动心跳（可选）                                                   */
/* ================================================================== */

/**
 * 开启/关闭内置自动心跳线程（可选功能，默认关闭）。
 *
 * 开启后 DLL 内部按 interval_seconds 周期调用心跳（等价于调用方轮询
 * Nebula_Heartbeat），并自动补发积压的运行时事件。登录态失效（1002/1003）
 * 时会自动清除本地登录状态。interval_seconds <= 0 时使用服务端下发的
 * heartbeat_interval（默认 60 秒）。
 *
 * 重复调用会先停掉旧线程再按新参数重启；传 enable=0 停止。
 * 返回: 0=成功；负数=DLL 层错误
 */
NEBULA_API int __stdcall Nebula_SetAutoHeartbeat(NEBULA_HANDLE handle,
    int enable, int interval_seconds);

/* ================================================================== */
/*  状态查询                                                          */
/* ================================================================== */

/** 获取当前 SDK 状态 (返回 NebulaState 枚举值) */
NEBULA_API int __stdcall Nebula_GetState(NEBULA_HANDLE handle);

/* ================================================================== */
/*  内置提示框 (MessageBox) — 方便调用方直接使用                      */
/* ================================================================== */

/**
 * 弹出上一次操作的错误提示框。
 *
 * 自动读取 lastError / lastErrorMsg，以 Windows MessageBox 弹出。
 * - 成功时 (lastError == 0) 不弹框，返回 NEBULA_OK。
 * - 失败时弹出错误码 + 描述，标题默认 "Nebula SDK"。
 * - hwnd 可为 NULL (无父窗口)。
 *
 * 返回值: MessageBox 的返回值 (IDOK=1, IDYES=6, IDNO=7, ...)。
 */
NEBULA_API int __stdcall Nebula_ShowErrorBox(NEBULA_HANDLE handle, void* hwnd);

/**
 * 弹出上一次操作的结果提示框（JSON 结果）。
 *
 * 读取 GetResult 的 JSON 内容，以 MessageBox 弹出。
 * - 成功显示绿色信息图标 (MB_ICONINFORMATION)。
 * - 失败显示红色错误图标 (MB_ICONERROR)。
 * - hwnd 可为 NULL。
 *
 * 返回值: MessageBox 的返回值。
 */
NEBULA_API int __stdcall Nebula_ShowResultBox(NEBULA_HANDLE handle, void* hwnd);

/**
 * 设置自定义提示框回调函数（高级用法）。
 *
 * 设置后，ShowErrorBox / ShowResultBox 会调用此回调而非系统 MessageBox。
 * 传 NULL 恢复为系统默认 MessageBox。
 *
 * 参数:
 *   handle    - SDK 实例
 *   callback  - 回调函数指针，签名为:
 *     void NEBULA_UI_CALLBACK(const char* title, const char* message, int is_error, void* user_data)
 *   user_data - 透传给回调的用户自定义指针
 *
 * 返回 NEBULA_OK 或错误码。
 */
typedef void (__stdcall *NEBULA_UI_CALLBACK)(const char* title, const char* message, int is_error, void* user_data);

NEBULA_API int __stdcall Nebula_SetUICallback(NEBULA_HANDLE handle,
    NEBULA_UI_CALLBACK callback, void* user_data);

#ifdef __cplusplus
}
#endif
