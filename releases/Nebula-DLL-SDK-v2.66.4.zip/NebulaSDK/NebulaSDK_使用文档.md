# NebulaSDK DLL 使用文档

**版本**: 2.1  
**协议**: Nebula 3.1  
**适用平台**: Windows 7+ (x86 / x64)  
**调用约定**: `__stdcall`  
**字符串编码**: UTF-8 (`char*`)

---

## 目录

1. [交付物清单](#1-交付物清单)
2. [快速开始](#2-快速开始)
3. [两种接入方式](#3-两种接入方式)
4. [使用流程](#4-使用流程)
5. [API 参考手册](#5-api-参考手册)
6. [错误码](#6-错误码)
7. [SDK 状态机](#7-sdk-状态机)
8. [返回 JSON 格式说明](#8-返回-json-格式说明)
9. [各语言接入示例](#9-各语言接入示例)
10. [注意事项](#10-注意事项)
11. [安全特性](#11-安全特性)

---

## 1. 交付物清单

| 文件 | 说明 |
|------|------|
| `NebulaSDK_x86.dll` / `NebulaSDK_x86.lib` | 32 位版本，适用于 x86 程序 |
| `NebulaSDK_x64.dll` / `NebulaSDK_x64.lib` | 64 位版本，适用于 x64 程序 |
| `NebulaSDK.h`  | C 语言头文件，包含所有 API 声明、错误码、状态枚举（x86/x64 通用） |

编译环境：Visual Studio 2022 (v145 工具集)，C++20，Windows SDK 10。

**v2.0 新增**：
- 内置提示框 API（`Nebula_ShowErrorBox` / `Nebula_ShowResultBox` / `Nebula_SetUICallback`）
- 提示框标题自动使用服务端 `init` 下发的软件名称
- 敏感内存清零保护
- Release 编译加固（符号隐藏、字符串合并、代码折叠）
- 反调试检测（仅 Release 构建）

**v2.1 修复与加固**：
- **修复登录请求 JSON 序列化缺陷**：`const char*` 实参曾因 C++ 重载决议被隐式转换为 `bool`，导致登录请求发出 `"code": true` / `"username": true`，服务端返回 3001（激活码不存在）/ 1001。现已新增显式 `const char*` 重载，三种登录方式均恢复正常
- **修复 Feature 解密密钥派生**：改为与服务端 / C++ / C# / Python SDK 一致的域分离约定 `SHA256(feature_key + "|nebula-feature-aes")` / `SHA256(feature_key + "|nebula-feature-mac")`，此前派生不一致导致 `Nebula_DecryptFeature` 必然验签失败
- **登录自动声明 `capabilities.runtime_guard=true`**：与服务端 require_runtime_guard 强制策略对齐，避免被 7002 拒绝登录
- **响应会话一致性校验**：解密响应前校验响应 `sid` 与当前会话一致，防串会话

---

## 2. 快速开始

```c
#include "NebulaSDK.h"
#include <stdio.h>

int main() {
    NEBULA_HANDLE h = Nebula_Create();
    if (!h) { printf("Create failed\n"); return 1; }

    Nebula_SetServer(h, "https://your-server.com");
    Nebula_SetAppKey(h, "YOUR_APP_KEY");
    Nebula_SetClientVersion(h, "1.0.0");
    Nebula_SetMachineId(h, "MACHINE_ID");

    int ret = Nebula_Handshake(h);
    if (ret != 0) {
        Nebula_ShowErrorBox(h, NULL);  // 直接弹出错误提示框
        Nebula_Destroy(h);
        return 1;
    }

    Nebula_Init(h);

    ret = Nebula_LoginPassword(h, "your_username", "your_password");
    if (ret == 0) {
        char result[16384];
        Nebula_GetResult(h, result, sizeof(result));
        printf("Login OK: %s\n", result);
        Nebula_Heartbeat(h);
        Nebula_Logout(h);
    } else {
        Nebula_ShowErrorBox(h, NULL);
    }

    Nebula_Destroy(h);
    return 0;
}
```

编译（x86 示例）：`cl /EHsc main.c /link NebulaSDK_x86.lib`

> 64 位程序使用 `NebulaSDK_x64.lib` / `NebulaSDK_x64.dll`。

运行时确保对应架构的 `.dll` 与 `.exe` 在同一目录。

---

## 3. 两种接入方式

### 3.1 静态链接（.lib 导入）

**适用场景**: C/C++、易语言

**所需文件**: `NebulaSDK.h` + `NebulaSDK_x86.lib` / `NebulaSDK_x64.lib` + 对应的 `.dll`

**MSVC 命令行**:
```bat
cl /EHsc main.cpp /I. /link NebulaSDK_x86.lib    :: 32 位
cl /EHsc main.cpp /I. /link NebulaSDK_x64.lib    :: 64 位
```

**Visual Studio 项目设置**:
- 链接器 → 输入 → 附加依赖项：添加 `NebulaSDK_x86.lib` 或 `NebulaSDK_x64.lib`（根据目标架构）
- 链接器 → 常规 → 附加库目录：添加 `.lib` 所在路径
- C/C++ → 常规 → 附加包含目录：添加 `NebulaSDK.h` 所在路径

> 即使使用 .lib 静态链接，运行时仍然需要对应架构的 `.dll`。.lib 只是导入库。

### 3.2 动态加载（LoadLibrary）

**适用场景**: C#、Python、Delphi 或需要运行时按需加载的场景

**所需文件**: `NebulaSDK_x86.dll` 或 `NebulaSDK_x64.dll` + `NebulaSDK.h`（仅作参考）

```c
// 根据程序架构选择对应的 DLL 名称
HMODULE dll = LoadLibraryA("NebulaSDK_x86.dll");  // 32 位程序
// HMODULE dll = LoadLibraryA("NebulaSDK_x64.dll");  // 64 位程序
auto fnCreate       = (FN_Create)GetProcAddress(dll, "Nebula_Create");
auto fnHandshake    = (FN_Handshake)GetProcAddress(dll, "Nebula_Handshake");
auto fnShowErrorBox = (FN_ShowErrorBox)GetProcAddress(dll, "Nebula_ShowErrorBox");

NEBULA_HANDLE h = fnCreate();
if (fnHandshake(h) != 0) {
    fnShowErrorBox(h, NULL);
}
```

---

## 4. 使用流程

```
Nebula_Create              创建实例
    |
    v
Nebula_SetServer           设置服务器地址
Nebula_SetAppKey           设置 AppKey
Nebula_SetClientVersion    设置客户端版本
Nebula_SetMachineId        设置机器 ID
Nebula_SetRespSignKey      (可选) 设置响应签名公钥
Nebula_SetDeviceInfo       (可选) 设置设备指纹
    |
    v
Nebula_Handshake           ECDH P-256 握手，建立加密通道
    |
    v
Nebula_Init                初始化，拉取服务端配置（含软件名称）
    |
    v
Nebula_LoginPassword       登录 (三选一)
Nebula_LoginUsernameCode
Nebula_LoginCard
    |
    v
Nebula_Heartbeat           心跳保活
Nebula_GetUserInfo         获取用户信息
Nebula_GetDevices          获取设备列表
Nebula_GetNotice           获取公告
Nebula_CheckVersion        版本检查
Nebula_GetOnline           在线人数
Nebula_Activate            激活卡密
Nebula_Unbind              解绑设备
Nebula_DecryptFeature      解密 Feature 数据
Nebula_ShowErrorBox        (便捷) 弹出错误提示框
Nebula_ShowResultBox       (便捷) 弹出结果提示框
    |
    v
Nebula_Logout              退出登录
    |
    v
Nebula_Destroy             销毁实例
```

---

## 5. API 参考手册

所有函数均使用 `__stdcall` 调用约定，字符串参数为 UTF-8 编码的 `const char*`。

### 5.1 生命周期

#### `Nebula_Create`

```c
NEBULA_HANDLE Nebula_Create(void);
```

创建 SDK 实例。返回非 `NULL` 表示成功，`NULL` 表示失败（内存不足）。

---

#### `Nebula_Destroy`

```c
void Nebula_Destroy(NEBULA_HANDLE handle);
```

销毁 SDK 实例，释放所有内部资源。销毁时自动清零所有敏感密钥内存（会话密钥、FeatureKey 等），然后释放。调用后句柄失效。

---

### 5.2 配置

#### `Nebula_SetServer`

```c
int Nebula_SetServer(NEBULA_HANDLE handle, const char* server_url);
```

设置服务器地址，如 `"https://your-server.com"`。**必须在握手前调用。**

---

#### `Nebula_SetAppKey`

```c
int Nebula_SetAppKey(NEBULA_HANDLE handle, const char* app_key);
```

设置 AppKey（软件标识码）。**必须在握手前调用。**

---

#### `Nebula_SetClientVersion`

```c
int Nebula_SetClientVersion(NEBULA_HANDLE handle, const char* version);
```

设置客户端版本号，如 `"1.0.0"`。

---

#### `Nebula_SetMachineId`

```c
int Nebula_SetMachineId(NEBULA_HANDLE handle, const char* machine_id);
```

设置机器码（用于设备绑定验证）。**必填，不能为空。**

调用方需自行采集机器标识传入，DLL 不自动采集硬件信息（避免 WMI 权限、虚拟机兼容、易语言环境差异等问题）。

常见的机器码采集方式：
- 硬盘序列号、CPU ID、主板序列号等单项
- 多项拼接后取 SHA256
- Windows 产品 ID

登录时服务端自动处理设备绑定：已绑定的设备直接通过，未绑定的设备在未达上限时自动绑定，达到上限则拒绝登录（返回 `4001`）。无需手动开关。

---

#### `Nebula_SetDeviceInfo`

```c
int Nebula_SetDeviceInfo(NEBULA_HANDLE handle,
    const char* board, const char* cpu, const char* disk,
    const char* bios, const char* mac, const char* gpu);
```

设置设备指纹信息（可选）。传入 `NULL` 表示跳过该项。

| 参数 | 说明 |
|------|------|
| `board` | 主板序列号，`NULL` 跳过 |
| `cpu` | CPU ID，`NULL` 跳过 |
| `disk` | 硬盘序列号，`NULL` 跳过 |
| `bios` | BIOS 序列号，`NULL` 跳过 |
| `mac` | MAC 地址，`NULL` 跳过 |
| `gpu` | GPU 标识，`NULL` 跳过 |

---

#### `Nebula_SetRespSignKey`

```c
int Nebula_SetRespSignKey(NEBULA_HANDLE handle, const char* pem_public_key);
```

设置响应签名验证公钥（ES256 / ECDSA P-256 PEM 格式）。设置后 SDK 自动验证握手响应和业务响应的数字签名，防止中间人篡改。

**PEM 格式示例**（请替换为你自己服务端的公钥）：
```
-----BEGIN PUBLIC KEY-----
<你的 ES256 (ECDSA P-256) 公钥 PEM 内容>
-----END PUBLIC KEY-----
```

> 公钥需与服务端签名私钥配对，由服务端管理员在后台生成并下发。

---

### 5.3 握手与初始化

#### `Nebula_Handshake`

```c
int Nebula_Handshake(NEBULA_HANDLE handle);
```

执行 Nebula 3.1 ECDH P-256 握手，建立加密通信通道。

**前置条件**: 已调用 `SetServer` 和 `SetAppKey`

**返回值**: `0` 成功，负数为 SDK 内部错误

握手成功后自动派生会话密钥（ECDH → HKDF → sk_enc / sk_mac / sk_enc_rsp），ECDH 临时私钥和共享密钥用完即清零。

---

#### `Nebula_Init`

```c
int Nebula_Init(NEBULA_HANDLE handle);
```

初始化，向服务端拉取配置（安全策略、功能开关、软件信息等）。

**前置条件**: 握手成功

**返回值**: `0` 成功，正数为服务端业务错误码，负数为 SDK 内部错误

初始化成功后，SDK 自动从响应中提取软件名称（`data.software.name`），用于后续提示框标题。未初始化时提示框标题使用默认值 `"Nebula SDK"`。

---

### 5.4 登录

三种登录方式，登录成功后 SDK 内部自动保存 token 和 feature_key。

> **v2.1 起**：登录请求会自动携带 `capabilities: {"runtime_guard": true}`，无需调用方干预；服务端开启 RuntimeGuard 强制策略时可正常放行。

#### `Nebula_LoginPassword`

```c
int Nebula_LoginPassword(NEBULA_HANDLE handle,
    const char* username, const char* password);
```

用户名 + 密码登录。返回 `0` 成功，`1002`/`1003` 需重新登录，其他正数为业务错误码。

---

#### `Nebula_LoginUsernameCode`

```c
int Nebula_LoginUsernameCode(NEBULA_HANDLE handle,
    const char* username, const char* code);
```

用户名 + 激活码登录。

---

#### `Nebula_LoginCard`

```c
int Nebula_LoginCard(NEBULA_HANDLE handle, const char* code);
```

卡密直接登录（无需用户名）。

---

### 5.5 业务接口

以下接口均需在登录成功后调用。

#### `Nebula_Heartbeat`

```c
int Nebula_Heartbeat(NEBULA_HANDLE handle);
```

发送心跳包，建议每 30~60 秒调用一次。返回 `1002`/`1003` 表示会话失效。

---

#### `Nebula_GetUserInfo`

```c
int Nebula_GetUserInfo(NEBULA_HANDLE handle);
```

获取当前登录用户信息。

---

#### `Nebula_GetDevices`

```c
int Nebula_GetDevices(NEBULA_HANDLE handle);
```

获取当前账号绑定的设备列表。

---

#### `Nebula_Activate`

```c
int Nebula_Activate(NEBULA_HANDLE handle, const char* code);
```

激活卡密（将卡密绑定到当前账号）。

---

#### `Nebula_Unbind`

```c
int Nebula_Unbind(NEBULA_HANDLE handle, const char* password, int all);
```

解绑设备。`password` 为用户密码（可为 `NULL`），`all` 为 `1` 解绑全部，`0` 解绑当前设备。

---

#### `Nebula_GetNotice`

```c
int Nebula_GetNotice(NEBULA_HANDLE handle, const char* notice_id);
```

获取公告。`notice_id` 传 `NULL` 或空字符串获取最新公告。

---

#### `Nebula_CheckVersion`

```c
int Nebula_CheckVersion(NEBULA_HANDLE handle, const char* channel);
```

版本检查。`channel` 传 `NULL` 默认 `"stable"`。

---

#### `Nebula_GetOnline`

```c
int Nebula_GetOnline(NEBULA_HANDLE handle);
```

获取当前在线人数。

---

#### `Nebula_Logout`

```c
int Nebula_Logout(NEBULA_HANDLE handle);
```

退出登录。退出时自动清零 feature_key。退出后可重新登录。

---

### 5.6 Feature 解密

#### `Nebula_DecryptFeature`

```c
int Nebula_DecryptFeature(NEBULA_HANDLE handle,
    const char* feature_data, char* buffer, uint32_t buffer_size);
```

解密 Feature 数据（NF1 格式）。

| 参数 | 类型 | 说明 |
|------|------|------|
| `handle` | `NEBULA_HANDLE` | SDK 实例句柄 |
| `feature_data` | `const char*` | NF1 格式密文：`NF1.<base64>.<hmac_hex>` |
| `buffer` | `char*` | 输出缓冲区 |
| `buffer_size` | `uint32_t` | 缓冲区大小 |

**返回值**: `>= 0` 成功（写入字节数），负数失败

**前置条件**: 已登录（SDK 内部持有 `feature_key`）

**NF1 格式**:
```
NF1.<base64(iv + AES-256-CBC密文)>.<hex(HMAC-SHA256)>
```
- 加密：AES-256-CBC + HMAC-SHA256（encrypt-then-MAC）
- 密钥派生：`SHA256(feature_key + "|nebula-feature-aes")` → AES 密钥，`SHA256(feature_key + "|nebula-feature-mac")` → HMAC 密钥（v2.1 起与服务端及其余 SDK 一致）
- 先验证 HMAC，通过后才解密
- 解密完成后 AES 密钥、HMAC 密钥和明文中间副本立即清零

---

### 5.7 结果与状态

#### `Nebula_GetResult`

```c
int Nebula_GetResult(NEBULA_HANDLE handle, char* buffer, uint32_t buffer_size);
```

获取上次操作的 JSON 结果。返回 `> 0` 为写入字节数。

**JSON 格式**:
```json
{
    "code": 0,
    "msg": "ok",
    "success": true,
    "data": { ... },
    "need_relogin": false,
    "need_update": false,
    "force_offline": false
}
```

---

#### `Nebula_GetLastError`

```c
int Nebula_GetLastError(NEBULA_HANDLE handle);
```

获取最后错误码，`0` 表示无错误。

---

#### `Nebula_GetLastErrorMessage`

```c
int Nebula_GetLastErrorMessage(NEBULA_HANDLE handle, char* buffer, uint32_t buffer_size);
```

获取最后错误的文字描述。

---

#### `Nebula_GetState`

```c
int Nebula_GetState(NEBULA_HANDLE handle);
```

获取当前 SDK 状态，返回 `NebulaState` 枚举值。

---

### 5.8 内置提示框

SDK 内置便捷提示框功能，调用方无需自己解析错误码和拼接信息，直接弹窗即可。提示框标题自动使用 `Nebula_Init` 时服务端下发的软件名称（`data.software.name`），未初始化时使用默认值 `"Nebula SDK"`。

#### `Nebula_ShowErrorBox`

```c
int Nebula_ShowErrorBox(NEBULA_HANDLE handle, void* hwnd);
```

弹出上一次操作的错误提示框。

| 参数 | 类型 | 说明 |
|------|------|------|
| `handle` | `NEBULA_HANDLE` | SDK 实例句柄 |
| `hwnd` | `void*` | 父窗口句柄，可为 `NULL` |

**行为**:
- 成功时（`lastError == 0`）不弹框，返回 `NEBULA_OK`
- 失败时弹出错误码 + 描述：`[错误码] 错误描述`
- 红色错误图标（`MB_ICONERROR`）
- 标题为服务端下发的软件名称

**返回值**: `MessageBox` 返回值（如 `IDOK=1`）

```c
int ret = Nebula_Handshake(h);
if (ret != 0) {
    Nebula_ShowErrorBox(h, NULL);  // 直接弹框，无需自己拼错误
}
```

---

#### `Nebula_ShowResultBox`

```c
int Nebula_ShowResultBox(NEBULA_HANDLE handle, void* hwnd);
```

弹出上一次操作的 JSON 结果提示框。

**行为**:
- 成功：绿色信息图标（`MB_ICONINFORMATION`），标题 `软件名称 - 操作结果`
- 失败：红色错误图标（`MB_ICONERROR`），标题 `软件名称 - 操作失败`

```c
int ret = Nebula_LoginPassword(h, "your_username", "your_password");
if (ret == 0) {
    Nebula_ShowResultBox(h, NULL);  // 弹出登录结果 JSON
}
```

---

#### `Nebula_SetUICallback`

```c
typedef void (__stdcall *NEBULA_UI_CALLBACK)(
    const char* title,     // 标题 (UTF-8)
    const char* message,   // 消息内容 (UTF-8)
    int is_error,          // 1=错误, 0=成功
    void* user_data        // 用户自定义数据指针
);

int Nebula_SetUICallback(NEBULA_HANDLE handle,
    NEBULA_UI_CALLBACK callback, void* user_data);
```

设置自定义提示框回调（高级用法）。设置后 `ShowErrorBox`/`ShowResultBox` 调用此回调而非系统 `MessageBox`。传 `NULL` 恢复默认。

| 参数 | 类型 | 说明 |
|------|------|------|
| `handle` | `NEBULA_HANDLE` | SDK 实例句柄 |
| `callback` | `NEBULA_UI_CALLBACK` | 回调函数指针，`NULL` 恢复默认 |
| `user_data` | `void*` | 透传给回调的用户自定义指针 |

**使用场景**: 需要自定义提示框样式（如易语言自定义弹窗、C# WinForms MessageBox）时使用。

```c
void __stdcall myCallback(const char* title, const char* message,
                          int is_error, void* user_data) {
    printf("[%s] %s (error=%d)\n", title, message, is_error);
}

Nebula_SetUICallback(h, myCallback, NULL);
Nebula_ShowErrorBox(h, NULL);  // 会调用 myCallback
```

---

## 6. 错误码

### SDK 内部错误码（负数）

| 错误码 | 宏名 | 说明 |
|--------|------|------|
| 0 | `NEBULA_OK` | 成功 |
| -1 | `NEBULA_ERR_INVALID_HANDLE` | 无效句柄 |
| -2 | `NEBULA_ERR_INVALID_ARG` | 无效参数 |
| -3 | `NEBULA_ERR_NOT_INIT` | 未初始化 |
| -4 | `NEBULA_ERR_NETWORK` | 网络错误 |
| -5 | `NEBULA_ERR_TIMEOUT` | 超时 |
| -6 | `NEBULA_ERR_HTTP` | HTTP 错误 |
| -7 | `NEBULA_ERR_JSON` | JSON 解析错误 |
| -8 | `NEBULA_ERR_CRYPTO` | 加密/解密错误 |
| -9 | `NEBULA_ERR_BUFFER_SMALL` | 缓冲区不足 |
| -10 | `NEBULA_ERR_INTERNAL` | 内部错误 |
| -11 | `NEBULA_ERR_NOT_LOGGED_IN` | 未登录 |
| -12 | `NEBULA_ERR_SESSION_EXPIRED` | 会话过期 |

### 服务端业务错误码（正数）

| code | 含义 |
|------|------|
| 0 | 成功 |
| 1001 | 参数错误 |
| 1002 | 未登录 / 令牌无效 |
| 1003 | 令牌过期 |
| 1004 | app_key 无效或软件已停用 |
| 2001 | 用户名或密码错误 |
| 2002 | 账号已被封禁 |
| 2003 | 账号被锁定 |
| 2004 | 账号已过期，需激活 |
| 3001 | 卡密不存在 |
| 3002 | 卡密已被使用 |
| 3003 | 卡密已作废 |
| 3004 | 卡密已过期 |
| 4001 | 设备数量超限 |
| 4002 | 设备未绑定 / 已被解绑 |
| 4004 | 设备已被拉黑 |
| 5001 | 请求过于频繁 |
| 5002 | 签名校验失败 |
| 6001 | 版本过低需强制更新 |
| 6002 | 服务器维护中 |
| 9999 | 服务器内部错误 |

---

## 7. SDK 状态机

```
CREATED(0)          创建实例后的初始状态
    |
    v
HANDSHAKING(1)      握手进行中
    |
    v
ESTABLISHED(2)      握手完成，加密通道已建立
    |
    v
INITIALIZED(3)      初始化完成（已拉取配置，获取软件名称）
    |
    v
LOGGED_IN(4)        已登录
    |
    v
LOGGED_OUT(5)       已退出登录（可重新登录）
    |
    v
DESTROYED(6)        已销毁（终态）
```

**异常状态转换**:
- `LOGGED_IN` → 心跳返回 `1002`/`1003` → 回退到 `ESTABLISHED`（需重新登录）
- 任意状态 → `Nebula_Destroy` → `DESTROYED`

---

## 8. 返回 JSON 格式说明

`Nebula_GetResult` 返回的 JSON 统一格式：

| 字段 | 类型 | 说明 |
|------|------|------|
| `code` | int | 业务码，`0` 成功 |
| `msg` | string | 描述信息 |
| `success` | bool | 是否成功 |
| `data` | object | 业务数据 |
| `need_relogin` | bool | 是否需要重新登录 |
| `need_update` | bool | 是否需要更新版本 |
| `force_offline` | bool | 是否被强制下线 |

**登录成功时 data 示例**:
```json
{
    "token": "eyJ0eXAi...",
    "expire_at": 1735689600,
    "feature_key": "a1b2c3d4e5..."
}
```

**Init 响应 data 示例（部分字段）**:
```json
{
    "server_time": 1726003660,
    "app_key": "YOUR_APP_KEY",
    "software": { "id": 1, "name": "你的软件名称" },
    "site_name": "你的站点名称",
    "heartbeat_interval": 60,
    "session_ttl": 3600,
    "login": { "method": "password", ... },
    "version": { "latest": "1.0.0", "need_update": false },
    "grace": { "enable": false }
}
```

> SDK 自动从 `data.software.name` 提取软件名称用于提示框标题。

---

## 9. 各语言接入示例

### 9.1 C/C++（静态链接）

```c
#include "NebulaSDK.h"
#include <stdio.h>

int main() {
    NEBULA_HANDLE h = Nebula_Create();

    Nebula_SetServer(h, "https://your-server.com");
    Nebula_SetAppKey(h, "YOUR_APP_KEY");
    Nebula_SetClientVersion(h, "1.0.0");
    Nebula_SetMachineId(h, "MACHINE_ID");

    if (Nebula_Handshake(h) != 0) {
        Nebula_ShowErrorBox(h, NULL);
        Nebula_Destroy(h);
        return 1;
    }

    Nebula_Init(h);

    if (Nebula_LoginPassword(h, "your_username", "your_password") == 0) {
        char result[16384];
        Nebula_GetResult(h, result, sizeof(result));
        printf("Login: %s\n", result);
        Nebula_Heartbeat(h);
        Nebula_Logout(h);
    } else {
        Nebula_ShowErrorBox(h, NULL);
    }

    Nebula_Destroy(h);
    return 0;
}
```

---

### 9.2 易语言

DLL 命令声明：
```
.版本 2

.DLL命令 Nebula_Create, 整数型, "NebulaSDK_x86.dll", "Nebula_Create"
.DLL命令 Nebula_Destroy, , "NebulaSDK_x86.dll", "Nebula_Destroy"
    .参数 handle, 整数型
.DLL命令 Nebula_SetServer, 整数型, "NebulaSDK_x86.dll", "Nebula_SetServer"
    .参数 handle, 整数型
    .参数 server_url, 文本型
.DLL命令 Nebula_SetAppKey, 整数型, "NebulaSDK_x86.dll", "Nebula_SetAppKey"
    .参数 handle, 整数型
    .参数 app_key, 文本型
.DLL命令 Nebula_Handshake, 整数型, "NebulaSDK_x86.dll", "Nebula_Handshake"
    .参数 handle, 整数型
.DLL命令 Nebula_Init, 整数型, "NebulaSDK_x86.dll", "Nebula_Init"
    .参数 handle, 整数型
.DLL命令 Nebula_LoginPassword, 整数型, "NebulaSDK_x86.dll", "Nebula_LoginPassword"
    .参数 handle, 整数型
    .参数 username, 文本型
    .参数 password, 文本型
.DLL命令 Nebula_GetResult, 整数型, "NebulaSDK_x86.dll", "Nebula_GetResult"
    .参数 handle, 整数型
    .参数 buffer, 文本型
    .参数 buffer_size, 整数型
.DLL命令 Nebula_ShowErrorBox, 整数型, "NebulaSDK_x86.dll", "Nebula_ShowErrorBox"
    .参数 handle, 整数型
    .参数 hwnd, 整数型
.DLL命令 Nebula_ShowResultBox, 整数型, "NebulaSDK_x86.dll", "Nebula_ShowResultBox"
    .参数 handle, 整数型
    .参数 hwnd, 整数型
```

调用代码：
```
.子程序 启动
    .局部变量 handle, 整数型
    .局部变量 ret, 整数型
    .局部变量 result, 文本型

    handle ＝ Nebula_Create ()
    Nebula_SetServer (handle, "https://your-server.com")
    Nebula_SetAppKey (handle, "YOUR_APP_KEY")

    ret ＝ Nebula_Handshake (handle)
    .如果 (ret ＝ 0)
        Nebula_Init (handle)
        ret ＝ Nebula_LoginPassword (handle, "your_username", "your_password")
        .如果 (ret ＝ 0)
            result ＝ 取空白文本 (16384)
            Nebula_GetResult (handle, result, 16384)
            调试输出 (result)
            Nebula_Logout (handle)
        .否则
            ' 登录失败直接弹框，不需要自己拼错误信息
            Nebula_ShowErrorBox (handle, 0)
        .如果结束
    .否则
        ' 握手失败直接弹框
        Nebula_ShowErrorBox (handle, 0)
    .如果结束

    Nebula_Destroy (handle)
```

---

### 9.3 C#（P/Invoke）

```csharp
using System;
using System.Runtime.InteropServices;
using System.Text;

class NebulaSDK
{
    [DllImport("NebulaSDK_x86.dll", CallingConvention = CallingConvention.StdCall)]
    public static extern IntPtr Nebula_Create();

    [DllImport("NebulaSDK_x86.dll", CallingConvention = CallingConvention.StdCall)]
    public static extern void Nebula_Destroy(IntPtr handle);

    [DllImport("NebulaSDK_x86.dll", CallingConvention = CallingConvention.StdCall, CharSet = CharSet.Ansi)]
    public static extern int Nebula_SetServer(IntPtr handle, string server_url);

    [DllImport("NebulaSDK_x86.dll", CallingConvention = CallingConvention.StdCall, CharSet = CharSet.Ansi)]
    public static extern int Nebula_SetAppKey(IntPtr handle, string app_key);

    [DllImport("NebulaSDK_x86.dll", CallingConvention = CallingConvention.StdCall, CharSet = CharSet.Ansi)]
    public static extern int Nebula_SetClientVersion(IntPtr handle, string version);

    [DllImport("NebulaSDK_x86.dll", CallingConvention = CallingConvention.StdCall, CharSet = CharSet.Ansi)]
    public static extern int Nebula_SetMachineId(IntPtr handle, string machine_id);

    [DllImport("NebulaSDK_x86.dll", CallingConvention = CallingConvention.StdCall)]
    public static extern int Nebula_Handshake(IntPtr handle);

    [DllImport("NebulaSDK_x86.dll", CallingConvention = CallingConvention.StdCall)]
    public static extern int Nebula_Init(IntPtr handle);

    [DllImport("NebulaSDK_x86.dll", CallingConvention = CallingConvention.StdCall, CharSet = CharSet.Ansi)]
    public static extern int Nebula_LoginPassword(IntPtr handle, string username, string password);

    [DllImport("NebulaSDK_x86.dll", CallingConvention = CallingConvention.StdCall)]
    public static extern int Nebula_GetResult(IntPtr handle, StringBuilder buffer, uint buffer_size);

    [DllImport("NebulaSDK_x86.dll", CallingConvention = CallingConvention.StdCall)]
    public static extern int Nebula_ShowErrorBox(IntPtr handle, IntPtr hwnd);

    [DllImport("NebulaSDK_x86.dll", CallingConvention = CallingConvention.StdCall)]
    public static extern int Nebula_ShowResultBox(IntPtr handle, IntPtr hwnd);

    [DllImport("NebulaSDK_x86.dll", CallingConvention = CallingConvention.StdCall)]
    public static extern int Nebula_Heartbeat(IntPtr handle);

    [DllImport("NebulaSDK_x86.dll", CallingConvention = CallingConvention.StdCall)]
    public static extern int Nebula_Logout(IntPtr handle);
}

class Program
{
    static void Main()
    {
        IntPtr h = NebulaSDK.Nebula_Create();

        NebulaSDK.Nebula_SetServer(h, "https://your-server.com");
        NebulaSDK.Nebula_SetAppKey(h, "YOUR_APP_KEY");
        NebulaSDK.Nebula_SetClientVersion(h, "1.0.0");
        NebulaSDK.Nebula_SetMachineId(h, "MACHINE_ID");

        if (NebulaSDK.Nebula_Handshake(h) != 0)
        {
            NebulaSDK.Nebula_ShowErrorBox(h, IntPtr.Zero);
            NebulaSDK.Nebula_Destroy(h);
            return;
        }

        NebulaSDK.Nebula_Init(h);

        int ret = NebulaSDK.Nebula_LoginPassword(h, "your_username", "your_password");
        if (ret == 0)
        {
            StringBuilder sb = new StringBuilder(16384);
            NebulaSDK.Nebula_GetResult(h, sb, 16384);
            Console.WriteLine($"Login: {sb}");

            NebulaSDK.Nebula_Heartbeat(h);
            NebulaSDK.Nebula_Logout(h);
        }
        else
        {
            NebulaSDK.Nebula_ShowErrorBox(h, IntPtr.Zero);
        }

        NebulaSDK.Nebula_Destroy(h);
    }
}
```

---

### 9.4 Python（ctypes）

```python
import ctypes

dll = ctypes.WinDLL("NebulaSDK_x86.dll")  # 32 位程序；64 位用 "NebulaSDK_x64.dll"

dll.Nebula_Create.restype = ctypes.c_void_p
dll.Nebula_Create.argtypes = []

dll.Nebula_Destroy.restype = None
dll.Nebula_Destroy.argtypes = [ctypes.c_void_p]

dll.Nebula_SetServer.restype = ctypes.c_int
dll.Nebula_SetServer.argtypes = [ctypes.c_void_p, ctypes.c_char_p]

dll.Nebula_SetAppKey.restype = ctypes.c_int
dll.Nebula_SetAppKey.argtypes = [ctypes.c_void_p, ctypes.c_char_p]

dll.Nebula_SetClientVersion.restype = ctypes.c_int
dll.Nebula_SetClientVersion.argtypes = [ctypes.c_void_p, ctypes.c_char_p]

dll.Nebula_SetMachineId.restype = ctypes.c_int
dll.Nebula_SetMachineId.argtypes = [ctypes.c_void_p, ctypes.c_char_p]

dll.Nebula_Handshake.restype = ctypes.c_int
dll.Nebula_Handshake.argtypes = [ctypes.c_void_p]

dll.Nebula_Init.restype = ctypes.c_int
dll.Nebula_Init.argtypes = [ctypes.c_void_p]

dll.Nebula_LoginPassword.restype = ctypes.c_int
dll.Nebula_LoginPassword.argtypes = [ctypes.c_void_p, ctypes.c_char_p, ctypes.c_char_p]

dll.Nebula_GetResult.restype = ctypes.c_int
dll.Nebula_GetResult.argtypes = [ctypes.c_void_p, ctypes.c_char_p, ctypes.c_uint32]

dll.Nebula_ShowErrorBox.restype = ctypes.c_int
dll.Nebula_ShowErrorBox.argtypes = [ctypes.c_void_p, ctypes.c_void_p]

dll.Nebula_Heartbeat.restype = ctypes.c_int
dll.Nebula_Heartbeat.argtypes = [ctypes.c_void_p]

dll.Nebula_Logout.restype = ctypes.c_int
dll.Nebula_Logout.argtypes = [ctypes.c_void_p]

# 使用
h = dll.Nebula_Create()
dll.Nebula_SetServer(h, b"https://your-server.com")
dll.Nebula_SetAppKey(h, b"YOUR_APP_KEY")
dll.Nebula_SetClientVersion(h, b"1.0.0")
dll.Nebula_SetMachineId(h, b"MACHINE_ID")

ret = dll.Nebula_Handshake(h)
if ret == 0:
    dll.Nebula_Init(h)
    ret = dll.Nebula_LoginPassword(h, b"your_username", b"your_password")
    if ret == 0:
        buf = ctypes.create_string_buffer(16384)
        dll.Nebula_GetResult(h, buf, 16384)
        print("Login:", buf.value.decode("utf-8"))
        dll.Nebula_Heartbeat(h)
        dll.Nebula_Logout(h)
    else:
        dll.Nebula_ShowErrorBox(h, None)
else:
    dll.Nebula_ShowErrorBox(h, None)

dll.Nebula_Destroy(h)
```

---

## 10. 注意事项

### 10.1 线程安全

SDK 内部使用互斥锁保护，**所有 API 均可从不同线程调用同一个 handle**。但建议避免在高频并发场景下大量并发调用，因为内部锁会串行化请求。

### 10.2 字符串编码

所有 `const char*` 参数均为 **UTF-8** 编码：
- C/C++：直接传入 UTF-8 字符串
- C#：P/Invoke 使用 `CharSet.Ansi`，纯 ASCII 无影响；含非 ASCII 需手动转 UTF-8
- Python：传入 `bytes` 类型（如 `b"text"` 或 `"中文".encode("utf-8")`）

### 10.3 缓冲区大小

- `Nebula_GetResult`：建议至少 `16384` 字节（16KB）
- `Nebula_GetLastErrorMessage`：建议至少 `1024` 字节
- `Nebula_DecryptFeature`：建议至少 `8192` 字节
- 返回值为实际写入的字节数（不含 `\0`）；若缓冲区不足，结果会被截断

### 10.4 内存管理

SDK 与调用方之间**不传递动态分配的指针**，所有输出均通过调用方提供的缓冲区返回。调用方无需（也不应）释放任何 SDK 返回的数据。

### 10.5 网络超时

SDK 内部 HTTP 超时设置：
- 连接超时：10 秒
- 发送超时：10 秒
- 接收超时：30 秒

### 10.6 HTTPS 证书

SDK 默认不验证 SSL 证书，这适用于开发调试和自签名证书的场景。如果你的服务端使用受信任 CA 签发的证书并希望启用严格验证，可以在 `Nebula_Handshake` 之前调用 `Nebula_SetRespSignKey` 设置签名公钥，SDK 会通过 ES256 数字签名验证服务端响应的真实性，即使不验证 SSL 证书也能防止中间人篡改。

换句话说：**SSL 证书验证可以忽略，但签名验证不可忽略**——只要你设置了 `Nebula_SetRespSignKey`，攻击者即使能拦截 HTTPS 流量也无法伪造响应数据。

### 10.7 密钥安全

SDK 不提供任何获取内部密钥的接口（如会话密钥、ECDH 私钥、feature_key 等）。这些密钥仅在 SDK 内部使用，不会泄露给调用方。

### 10.8 架构匹配

确保 DLL 与调用程序的架构一致：
- 32 位程序使用 `NebulaSDK_x86.dll` + `NebulaSDK_x86.lib`
- 64 位程序使用 `NebulaSDK_x64.dll` + `NebulaSDK_x64.lib`
- 混用会导致 `LoadLibrary` 失败

### 10.9 提示框标题

提示框标题由 `Nebula_Init` 时服务端下发的 `data.software.name` 自动设置。如果未调用 `Init` 或 `Init` 失败，标题使用默认值 `"Nebula SDK"`。开发者只需在服务端后台修改软件名称，DLL 弹出的提示框标题就自动跟着变，不需要改代码重新编译。

---

## 11. 安全特性

### 11.1 协议层安全

| 安全机制 | 说明 |
|----------|------|
| ECDH P-256 密钥交换 | 每次握手生成临时密钥对，私钥用完即清零 |
| HKDF-SHA256 密钥派生 | 从共享密钥派生独立的加密/MAC 密钥 |
| AES-256-GCM 加密 | 业务请求和响应均经过认证加密 |
| HMAC-SHA256 | 防止请求篡改和重放 |
| ES256 签名验证 | 验证服务端握手签名和响应签名，防中间人 |
| 序列号 (seq) | 每次请求递增，防止重放攻击 |
| 协议版本锁定 | 固定 proto=31，拒绝旧协议降级 |

### 11.2 敏感内存保护

SDK 在以下时机使用 `SecureZeroMemory` 清零敏感数据：

| 时机 | 清零内容 |
|------|---------|
| 握手完成后 | ECDH 私钥 BLOB、共享密钥、中间密钥副本 |
| Feature 解密完成后 | AES 密钥、HMAC 密钥、明文中间副本 |
| `Nebula_Logout` | feature_key |
| `Nebula_Destroy` | 所有会话密钥（skEnc/skMac/skEncRsp/ivPrefix）+ feature_key |

### 11.3 Release 编译加固

Release 构建启用以下加固选项：

| 加固选项 | 效果 |
|----------|------|
| `OmitFramePointers` | 省略帧指针，增加栈分析难度 |
| `StringPooling` | 合并相同字符串，减少可读字符串 |
| `/Gs1048576` | 栈探针 |
| `/Zc:inline` | 移除未引用的内联函数符号 |
| `OptimizeReferences` | 清除未引用代码 |
| `EnableCOMDATFolding` | 合并重复函数代码 |
| `SetChecksum` | 写入 PE 校验和 |
| `LinkTimeCodeGeneration` | 全程序优化 |
| `GenerateDebugInformation=false` | 不生成 PDB |
| PostBuild 删除 .exp/.pdb | 确保无调试符号泄露 |

### 11.4 反调试检测

Release 构建中在 DLL 加载时执行三层反调试检测：

| 检测方式 | 说明 |
|----------|------|
| `IsDebuggerPresent` | 检测用户态调试器 |
| `CheckRemoteDebuggerPresent` | 检测远程调试器 |
| PEB `NtGlobalFlag` | 检测调试器设置的堆标志（x86/x64 分别处理） |

检测到调试器时 DLL 加载失败（返回 `FALSE`），不使用 `TerminateProcess`（更难被定位）。

> **注意**: 反调试仅在 Release 构建中启用，Debug 构建正常调试。这些检测只是辅助防线，不能防止所有调试器。真正的安全依赖于协议层密码学和服务端授权。

### 11.5 安全设计原则

本 SDK 遵循"协议安全作为基础，服务端授权作为核心"的原则：

- DLL 不持有任何长期秘密（服务器私钥只在服务端）
- DLL 不做本地授权判断（所有授权由服务端决定）
- 即使 DLL 被完全逆向，攻击者也无法伪造服务器响应（ES256 签名）
- 即使 DLL 被 patch，攻击者也无法获得服务器权限（服务端做最终判定）
- AppKey 可被提取但仅是标识，不是秘密凭证

---

*文档结束*